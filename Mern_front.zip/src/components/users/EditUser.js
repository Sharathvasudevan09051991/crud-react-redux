import React, { Component, useState, useEffect } from "react";
import { connect, useSelector, useDispatch } from "react-redux";
import {createUser, getUserByID } from '../../action/userAction';
import { useParams, withRouter, useHistory, useLocation } from 'react-router-dom';
import PropTypes from "prop-types";


const initialState = {
    name: '',
    email: '',
    password:''
}

export const EditUser = ({match, createUser, getUserByID, user, loading}) => {

    const params = useParams();

    const [formData, setFormData] = useState();

    // // const {name, email, password} = formData;


const nullUser = !user;
useEffect(() => {
  if (!user){
    console.log(params.id)
    getUserByID(params.id);
  } else{
    alert("USER")
    console.log("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", user);
    setFormData(user);

  }

  
}, [getUserByID, params.id, nullUser]);



    const handleSubmit = () => {
    console.log(formData);
    // createUser(formData);
    // setFormData(initialState);
   }

   
   const handleChange = (event) => {
     setFormData({...formData, [event.target.name]: event.target.value});
   }

   

  return (
        <div>
            <h1>Edit user</h1>

        <form>
        <div className="form-group">
          <input
            type="text"
            name="name"
            className="form-control"
            placeholder="Username"
            onChange={handleChange}
          />
        </div>
        <div className="form-group">
          <input
            type="text"
            name="email"
            className="form-control"
            placeholder="email"
            onChange={handleChange}
            // value={formData.email}


          />
        </div>
        <div className="form-group">
          <input
            type="text"
            name="password"
            className="form-control"
            placeholder="Password"
            onChange={handleChange}
            // value={formData.password}

          />
        </div>
        <button type="button" className="btn btn-primary" onClick={handleSubmit}>
          Submit
        </button>
      </form>
      </div>
  )
}

EditUser.propTypes = {
  user: PropTypes.object.isRequired,
  getUserByID: PropTypes.func.isRequired
};

const mapStateToProps = (state) => ({
    user :  state.user.user
})

export default connect(mapStateToProps, {getUserByID, createUser})(EditUser);
