import React, { useEffect, Fragment } from "react";
import PropTypes from "prop-types";
import { getAllUsers, getUserByID } from "../../action/userAction";
import { connect, useSelector, useDispatch } from "react-redux";
import { GET_USERS } from "../../action/actionTypes";
import { Link } from "react-router-dom";
import { useHistory } from 'react-router-dom'
import { AddUser } from "./AddUser";

const client_img = {
  width: "50px",
  height: "50px",
};

const ListUser = ({match}) => {
    
  // useEffect(() => {
  //     getAllUsers()
  // }, [getAllUsers]);

  const history = useHistory()

  const user = useSelector((state) => state.user.user);
  const users = useSelector((state) => state.user.users);
  const loading = useSelector((state) => state.user.loading);

  // const handleSubmit = (event) => {
  //     console.log(event);
  // }

  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAllUsers());
  }, []);

  const onClickEdit = (id) => {
      dispatch(getUserByID(id));
      history.push(`/edit-user/${id}`);
  }

  return (
    <div>
      <div>
        <button className="float-right btn btn-warning">
            <Link to="add-user">Add user</Link>
        </button>
      </div>
      <h1>LIST USER</h1>
      {loading ? (
        <Fragment>
          <div className="d-flex justify-content-center">
            <div className="spinner-border" role="status">
              <span className="sr-only">Loading...</span>
            </div>
          </div>
        </Fragment>
      ) : (
        <Fragment>
          <table className="table table-striped table-inverse table-responsive">
            <thead className="thead-inverse">
              <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Email</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user) => (
                <tr key={user._id}>
                  <td scope="row">
                    <img src={user.avatar} style={client_img} />
                  </td>
                  <td>{user.name}</td>
                  <td>{user.email}</td>
                  <td>
                    <button onClick={() => onClickEdit(user._id)}>Edit</button>
                    {/* <button className="btn btn-warning" onClick={() => { editemployee(user._id) }}>Edit</button>   */}
                    <button>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Fragment>
      )}
    </div>
  );
};

// const mapStateToProps = (state) => ({
//     users: state.user.users
// })

export default ListUser;


