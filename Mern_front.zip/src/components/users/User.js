import React  from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { useEffect } from 'react';
import {getAllUsers} from '../../action/userAction'
import ListUser from './ListUser';
import AddUser from './AddUser';

export const User = () => {
    return (
        <div className="container-fluid mt-2">
            <ListUser/>
        </div>
    )
}
export default User
