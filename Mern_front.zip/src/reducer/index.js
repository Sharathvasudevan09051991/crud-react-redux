import { combineReducers } from 'redux'
import  userReducer  from '../reducer/userReducer'

export default combineReducers({
    user: userReducer
})