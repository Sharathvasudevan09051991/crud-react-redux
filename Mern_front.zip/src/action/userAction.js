import portal from '../api/portal';
import axios from 'axios';
import {GET_USERS, USER_ERROR, ADD_USER, GET_USER } from '../action/actionTypes';

export const getAllUsers = () => async dispatch => {
    try{
        const res = await portal.get('api/users');
        console.log(res.data);
        dispatch({
            type: GET_USERS,
            payload: res.data
        })
    }
    catch (err) {
        dispatch({
          type: USER_ERROR,
          payload: { msg: err.response.statusText, status: err.response.status }
        });
      }

}

export const getUserByID = (id) => async dispatch => {
  try{
      const res = await portal.get(`api/users/${id}`);
      console.log(res.data);
      dispatch({
          type: GET_USER,
          payload: res.data
      })
  }
  catch (err) {
      dispatch({
        type: USER_ERROR,
        payload: { msg: err.response.statusText, status: err.response.status }
      });
    }

}

export const createUser = (formData) => async dispatch => {
  const config = {
    headers: {
      'Content-Type': 'application/json'
    }
  };
    debugger;
    try{
        const res = await portal.post('api/users', formData, config);
        const resGet = await portal.get('api/users');

        debugger;
        dispatch({
          type:GET_USERS,
          payload: resGet.data
        });
    }
    catch (err) {
      console.log(err.response)
        dispatch({
          type: USER_ERROR,
          payload: { msg: err.response.statusText, status: err.response.status }
        });
      }

}


export const deleteUser = () => async dispatch => {

} 