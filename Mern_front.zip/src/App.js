import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import { Provider } from 'react-redux';
import store from './store';
import { Fragment } from 'react';
import  ListUser  from './components/users/ListUser';
import  User  from './components/users/User';
import  AddUser  from './components/users/AddUser';
import EditUser from './components/users/EditUser';

function App() {
  return(
    <Provider store={store}>
    <Router>
      <Fragment>
        <Switch>
          <Route  exact path="/" component={User} />
          <Route  path="/list-user" component={ListUser} />
          <Route  path="/add-user" component={AddUser} />
          <Route  path="/edit-user/:id" component={EditUser} />

        </Switch>
      </Fragment>
    </Router>
  </Provider>
  )

}

export default App;
